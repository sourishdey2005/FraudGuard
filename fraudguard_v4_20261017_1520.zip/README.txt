FRAUDGUARD v4.0
Generated: 20261017_1520

CONTENTS
========

01_datasets/
    cleaned_fraud_data.csv         Final cleaned dataset (502,308 rows)
    messy_fraud_data_raw.csv       Raw messy dataset before cleaning

02_models/models_v4/
    fraudformer.keras              Custom transformer model (BEST MODEL)
    aegan_encoder.keras            AEGAN encoder
    aegan_decoder.keras            AEGAN decoder (fraud generator)
    aegan_discriminator.keras      AEGAN discriminator
    lgbm_baseline.txt              LightGBM baseline (text)
    lgbm_augmented.txt             LightGBM + AEGAN augmentation (text)
    scaler_ff.pkl                  StandardScaler for neural inputs
    iso_lgb.pkl                    Isotonic calibrator (LightGBM)
    iso_ff.pkl                     Isotonic calibrator (FraudFormer)
    iso_lgb_aug.pkl                Isotonic calibrator (LightGBM+AEGAN)
    features.pkl                   Ordered feature list (14 features)
    metadata.json                  Thresholds and hyperparameters
    final_comparison.csv           Test set metrics for all models

03_figures/figures_v4/
    01_fraudformer_curves.png      Loss and PR-AUC curves
    02_aegan_distribution.png      Real vs synthetic fraud distribution
    03_aegan_curves.png            AEGAN training curves
    04_all_models.png              ROC and PR curves (all models)
    05_confusions.png              Confusion matrices
    06_attention.png               FraudFormer attention heatmap

04_reports/
    final_comparison.csv           Full test metrics table
    metadata.json                  Model configuration

FINAL RESULTS (Test Set)
========================
Model                     ROC-AUC   PR-AUC    F1
FraudFormer (custom)      0.7692    0.5330    0.5864   <-- BEST
LightGBM + AEGAN          0.7652    0.5268    0.5741
LightGBM (baseline)       0.7661    0.5237    0.5667

DATASET
=======
Rows           : 502,308
Fraud rate     : 4.99%
Features used  : 14
Time split     : 70/15/15 (time-aware)

PIPELINE
========
1. Leak-free synthetic generation (single base distribution + interaction drift)
2. Cleaning (25+ messiness categories handled)
3. Time-aware split (no shuffling)
4. Feature engineering (14 raw + derived features)
5. LightGBM baseline (scale_pos_weight)
6. AEGAN (custom adversarial autoencoder)
7. FraudFormer (custom self-attention transformer)
8. Isotonic calibration
9. F1-optimal threshold selection
10. Test set evaluation

REPRODUCIBILITY
===============
Random seed     : 42
Python          : 3.10+
TensorFlow      : 2.x
LightGBM        : 4.x

USAGE
=====
# Load and predict with FraudFormer
from tensorflow.keras.models import load_model
import joblib
import numpy as np

model = load_model('02_models/models_v4/fraudformer.keras')
scaler = joblib.load('02_models/models_v4/scaler_ff.pkl')
features = joblib.load('02_models/models_v4/features.pkl')
meta = json.load(open('02_models/models_v4/metadata.json'))

def predict(transaction_dict):
    x = np.array([[transaction_dict[f] for f in features]])
    x = scaler.transform(x).clip(-8, 8)
    prob = model.predict(x, verbose=0)[0, 0]
    return {
        'fraud_probability': float(prob),
        'is_fraud': bool(prob >= meta['thresholds']['ff']),
        'threshold': meta['thresholds']['ff'],
    }

# Load and predict with LightGBM + AEGAN
import lightgbm as lgb
lgb_model = lgb.Booster(model_file='02_models/models_v4/lgbm_augmented.txt')
